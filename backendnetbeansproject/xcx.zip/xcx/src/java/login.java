/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author phani
 */
@WebServlet(urlPatterns = {"/login"})
public class login extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
             PrintWriter out=response.getWriter();
            
            String username=request.getParameter("username");
            String password=request.getParameter("password");
            String qwe="Login Unsuccessful";
             try{
             Class.forName("com.mysql.cj.jdbc.Driver");
             Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://192.168.31.158:3306/one?autoReconnect=true&useSSL=false","fakeman", "Aditya4334");
             Statement stmt = (Statement) conn.createStatement();
             String sql;
             sql = "SELECT * FROM userlist";
             ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                String uname = rs.getString("userid");
                String pname=rs.getString("password");
                if(username.equals(uname)&&password.equals(pname)){
                   qwe="Login Successful";
                   break;
                    

                }
             }
        }
        catch(Exception e){
            StringWriter errors = new StringWriter();
            e.printStackTrace(new PrintWriter(errors));
            out.write(errors.toString());
        }
             response.getWriter().append(qwe);
       
    }
}
