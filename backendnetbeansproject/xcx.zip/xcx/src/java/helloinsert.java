/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

/**
 *
 * @author phani
 */
@WebServlet(urlPatterns = {"/helloinsert"})
public class helloinsert extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            String name=request.getParameter("Name");
            String complaint=request.getParameter("Complaint");
            String fame="";
            
             DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd\nHH:mm:ss");  
             LocalDateTime now = LocalDateTime.now();
             String time_date=(String)dtf.format(now);
             complaint=complaint+"\n\n"+time_date;
            
             try{
             Class.forName("com.mysql.cj.jdbc.Driver");
             Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://192.168.31.158:3306/one?autoReconnect=true&useSSL=false","fakeman", "Aditya4334");
             Statement stmt = (Statement) conn.createStatement();
             String sql;
             sql = "INSERT INTO names(name) values('"+complaint+"')";
            stmt.executeUpdate(sql);
        }
        catch(Exception e){
            StringWriter errors = new StringWriter();
            e.printStackTrace(new PrintWriter(errors));
            fame=errors.toString();  
            PrintWriter out=response.getWriter();
            out.write(fame);
        }
             response.getWriter().append("Hello : "+name);
             response.getWriter().append("Is this for real?");
             response.getWriter().print("OK");
    }
}
